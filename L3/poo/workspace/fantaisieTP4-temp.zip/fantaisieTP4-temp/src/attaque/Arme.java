/**
 * 
 */
package attaque;

/**
 * @author tnt3192a
 *
 */
public abstract class Arme extends ForceDeCombat {

	protected Arme(int pointDeDegat, String nom) {
		super(pointDeDegat, nom);
	}

}
