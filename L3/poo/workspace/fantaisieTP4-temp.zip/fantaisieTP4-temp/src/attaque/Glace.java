/**
 * 
 */
package attaque;

/**
 * @author tnt3192a
 *
 */
public class Glace extends Pouvoir {
	public Glace(int pointDeDegat, String nom, int nbUtilisationPouvoir) {
		super(pointDeDegat, nom, nbUtilisationPouvoir);
	}

}
