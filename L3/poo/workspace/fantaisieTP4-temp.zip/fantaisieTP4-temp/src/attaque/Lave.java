/**
 * 
 */
package attaque;

/**
 * @author tnt3192a
 *
 */
public class Lave extends Feu {

	public Lave(int nbUtilisationPouvoir) {
		super(80, "Lave", nbUtilisationPouvoir);

	}
	
}
