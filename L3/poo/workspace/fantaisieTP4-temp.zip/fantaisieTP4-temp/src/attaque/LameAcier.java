/**
 * 
 */
package attaque;

/**
 * @author tnt3192a
 *
 */
public class LameAcier extends Tranchant {

	public LameAcier(int nbUtilisationPouvoir) {
		super(50, "Lames d'Acier", nbUtilisationPouvoir);
	}
	
}
