/**
 * 
 */
package attaque;

/**
 * @author tnt3192a
 *
 */
public class Griffe extends Tranchant {
	public Griffe() {
		super (20, "Griffe", 100);
	}
}
