package protagoniste;

import attaque.Pouvoir;

public class Monstre<P extends Pouvoir> extends EtreVivant {
	
}
