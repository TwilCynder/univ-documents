/**
 * 
 */
package attaque;

/**
 * @author tnt3192a
 *
 */
public class Feu extends Pouvoir {
	public Feu(int pointDeDegat, String nom, int nbUtilisationPouvoir) {
		super(pointDeDegat, nom, nbUtilisationPouvoir);
		// TODO Auto-generated constructor stub
	}

}
