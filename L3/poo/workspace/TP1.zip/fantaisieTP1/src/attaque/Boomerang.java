package attaque;

public class Boomerang extends Arme {
	public Boomerang() {
		super(10, "Boomerang");
	}
}
