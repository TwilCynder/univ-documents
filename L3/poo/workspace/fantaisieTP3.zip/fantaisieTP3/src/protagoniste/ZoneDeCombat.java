package protagoniste;

public enum ZoneDeCombat {
	AERIEN, AQUATIQUE, TERRESTRE
}
