/**
 * 
 */
package attaque;

/**
 * @author tnt3192a
 *
 */
public class BouleDeFeu extends Feu {

	public BouleDeFeu(int nbBoulesDeFeu) {
		super(20, "Boule de Feu", nbBoulesDeFeu);
		// TODO Auto-generated constructor stub
	}

}
