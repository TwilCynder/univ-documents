package livre;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.NavigableSet;
import java.util.TreeSet;

import bataille.Bataille;
import protagoniste.Domaine;
import protagoniste.Heros;
import protagoniste.Homme;
import protagoniste.Monstre;
import protagoniste.ZoneDeCombat;

public class AideEcrivain {
	private NavigableSet<Monstre<?>> monstresDomaineSet;
	private NavigableSet<Monstre<?>> monstresZoneSet;
	
	private NavigableSet<Monstre<?>> monstresDeFeu;
	private NavigableSet<Monstre<?>> monstresDeGlace;
	private NavigableSet<Monstre<?>> monstresTranchants;
	

	private Bataille bataille;

	public AideEcrivain(Bataille bataille) {
		this.bataille = bataille;
	}
	
	public LinkedList<Homme> visualiserForcesHumaines() {
		LinkedList<Homme> listeTriee = new LinkedList<>();
		
		ListIterator<Homme> iterHeros = listeTriee.listIterator();
		
		for (Homme h : bataille.getCampHumains()) {
			if (h instanceof Heros) {
				iterHeros.add(h);
			} else {
				listeTriee.add(h);
			}
		}
		
		/*for (Iterator<Homme> iterCamp = bataille.getCampHumains().iterator() ; iterCamp.hasNext();) {
			Homme h = iterCamp.next();
			if (h instanceof Heros) {
				iterHeros.add(h);
			} else {
				listeTriee.add(h);
			}
		}*/
		
		return listeTriee;
	}
	
	public String ordreNaturelMonstre() {
		//TODO OULA
		NavigableSet<Monstre<?>> tree = new TreeSet<Monstre<?>>();

		for (Monstre<?> m : bataille.getCampMonstres()) {
			tree.add(m);
		}
		
		String result = new String();
		
		for (Monstre<?> m : tree) {
			result += m + "  ";
		}
		
		return result;
			
	}
	
	public void updateMonstresDomaine() {
		monstresDomaineSet = new TreeSet<Monstre<?>>(
			new Comparator<Monstre<?>>() {
				public int compare(Monstre<?> m1, Monstre<?> m2) {
					Domaine d1 = m1.getDomaine();
					Domaine d2 = m2.getDomaine();
					if (d1 == d2) {
						return m1.compareTo(m2);
					} else {
						return d1.compareTo(d2);
					}
				}
			}
		);
		
		for (Monstre<?> m : bataille.getCampMonstres()) {
			monstresDomaineSet.add(m);
		}
	}
	
	public String ordreMonstreDomaine() {
		Domaine prevDom = null;
		String result = new String();
		updateMonstresDomaine();
		
		for (Monstre<?> m : monstresDomaineSet) {
			if (m.getDomaine() != prevDom) {
				prevDom = m.getDomaine();
				result += "\n" + prevDom + "\n";
			}
			
			result += m.getNom() + ",";
		}
		result += "\n";
		
		return result;
	}
	
	public void updateMonstreZone() {
		monstresZoneSet = new TreeSet<Monstre<?>>(
			new Comparator<Monstre<?>>() {
				public int compare(Monstre<?> m1, Monstre<?> m2) {
					ZoneDeCombat d1 = m1.getZoneDeCombat();
					ZoneDeCombat d2 = m2.getZoneDeCombat();
					if (d1 == d2) {
						return m1.compareTo(m2);
					} else {
						return d1.compareTo(d2);
					}
				}
			}
		);
		
		for (Monstre<?> m : bataille.getCampMonstres()) {
			monstresZoneSet.add(m);
		}
	}
	
	public String ordreMonstreZone() {
		ZoneDeCombat prevZone = null;
		String result = new String();
		updateMonstreZone();
		
		for (Monstre<?> m : monstresZoneSet) {
			if (m.getZoneDeCombat() != prevZone) {
				prevZone = m.getZoneDeCombat();
				result += "\n" + prevZone + "\n";
			}
			
			result += m.getNom() + " : " + m.getForceDeVie() + ", ";
		}
		result += "\n";
		
		return result;
	}
	
	public NavigableSet<Monstre<?>> getMonstresDeFeu() {
		return monstresDeFeu;
	}

	public NavigableSet<Monstre<?>> getMonstresDeGlace() {
		return monstresDeGlace;
	}

	public NavigableSet<Monstre<?>> getMonstresTranchants() {
		return monstresTranchants;
	}

	public Monstre<?> firstMonstreDomaine(Domaine domaine){
		for (Monstre<?> m : monstresDomaineSet) {
			if (m.getDomaine() == domaine) {
				return m;
			}
		}
		return null;
	}
	
}
