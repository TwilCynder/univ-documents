/**
 * 
 */
package attaque;

/**
 * @author tnt3192a
 *
 */
public abstract class Tranchant extends Pouvoir {

	protected Tranchant(int pointDeDegat, String nom, int nbUtilisationPouvoir) {
		super(pointDeDegat, nom, nbUtilisationPouvoir);
	}
	
}
