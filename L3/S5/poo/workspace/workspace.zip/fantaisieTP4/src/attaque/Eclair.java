/**
 * 
 */
package attaque;

/**
 * @author tnt3192a
 *
 */
public class Eclair extends Feu {

	public Eclair(int nbUtilisationPouvoir) {
		super(50, "�clair", nbUtilisationPouvoir);
		// TODO Auto-generated constructor stub
	}
	
}
