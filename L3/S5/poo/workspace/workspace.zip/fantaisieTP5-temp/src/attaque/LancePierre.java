/**
 * 
 */
package attaque;

import protagoniste.ZoneDeCombat;

/**
 * @author tnt3192a
 *
 */
public class LancePierre extends Arme {

	public LancePierre() {
		super(10, "Lance-Pierre", ZoneDeCombat.AERIEN, ZoneDeCombat.TERRESTRE);
	}

}
