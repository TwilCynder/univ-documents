package attaque;

public class KeyArme extends Arme {
	public KeyArme(int degats) {
		super (degats, "");
	}
}
