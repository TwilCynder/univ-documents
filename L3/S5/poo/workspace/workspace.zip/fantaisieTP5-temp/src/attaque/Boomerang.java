package attaque;

import protagoniste.ZoneDeCombat;

public class Boomerang extends Arme {
	public Boomerang() {
		super(10, "Boomerang", ZoneDeCombat.AERIEN, ZoneDeCombat.TERRESTRE);
	}
}
