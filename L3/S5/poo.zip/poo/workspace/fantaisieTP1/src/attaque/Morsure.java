/**
 * 
 */
package attaque;

/**
 * @author tnt3192a
 *
 */
public class Morsure extends Tranchant {

	public Morsure(int pointDeDegat) {
		super(pointDeDegat, "Morsure", 100);
	}
	
}
