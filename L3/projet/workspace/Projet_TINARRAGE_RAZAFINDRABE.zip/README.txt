Suite à une incompréhension de la date de rendu, à la disparition mystérieuse d'un membre du groupe, et à une mauvaise gestion de notre part,
ce projet a du être terminé dans l'urgence. C'est pourquoi nous n'avons pas pu réaliser les interfaces, mis à part une version primitive de l'interface client ;
nous avons cependant pu implémenter une bonne partie de la logique du système, notament côté serveur.

Éxécutables
- CreationBDD : crée la base de données.
- Serveur : lance le serveur. Il ne possède pas de GUI, mais communique sur la sortie standard.
- Client : lance le client. L'interface ne permet que de se login, mais la GUI de la partie messagerie est présente, ses fonctionnalités n'ayant pas pu être implélentées à temps.

================================
Pour créer la base de données : 
- Lancer le serveur MySQL
- éxécuter CréationBDD.jar

