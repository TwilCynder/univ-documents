package communication;

import java.io.Serializable;

public abstract class NetMessage implements Serializable {
	static final long serialVersionUID = 1L;
}
