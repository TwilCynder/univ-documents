package client;

public class Groupe {
	private String nom;
	
	public Groupe() {
		
	}

}
