package client;

import java.util.Date;

public class Message {
	private String idAuteur;
	private String nomAuteur;
	private String prenomAuteur;
	private Date date;
	private String contenu;
	
	public Message() {

	}

}
