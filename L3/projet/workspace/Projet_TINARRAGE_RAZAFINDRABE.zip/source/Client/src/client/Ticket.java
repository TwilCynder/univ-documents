package client;

public class Ticket {
	private int nbMessageNonLu;
	private String nom;
	
	public Ticket() {

	}

}
