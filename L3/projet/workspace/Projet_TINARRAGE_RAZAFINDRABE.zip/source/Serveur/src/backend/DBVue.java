package backend;

public abstract class DBVue {
	DataBase db;
	
	public DBVue(DataBase db){
		this.db = db;
	}
}
