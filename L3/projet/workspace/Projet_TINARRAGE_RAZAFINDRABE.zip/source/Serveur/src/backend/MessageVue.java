package backend;

public class MessageVue extends DBVue{

	public MessageVue(DataBase db, String idAuteur, String nomAuteur, String prenomAuteur) {
		super(db);
	}
	
}
