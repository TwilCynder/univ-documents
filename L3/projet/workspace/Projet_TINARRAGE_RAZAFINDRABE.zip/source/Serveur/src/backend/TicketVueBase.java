package backend;

public class TicketVueBase extends DBVue {
	private String titre;
	
	public TicketVueBase(DataBase db) {
		super(db);
	}
}
