package backend;

public class GroupeVue {

}
