package backend;

public enum TypeUtilisateur {
	CAMPUS,
	SERVICE
}
