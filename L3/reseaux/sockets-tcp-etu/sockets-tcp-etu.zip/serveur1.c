/* =================================================================== */
// Progrmame Serveur qui calcule le résultat d'un coup joué à partir
// des coordonnées reçues de la part d'un client "joueur".
// Version ITERATIVE : 1 seul client/joueur à la fois
/* =================================================================== */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include "tresor.h"

#define N 10
#define MSG_LEN 8
#define MAX_QLEN 16
#define DEFAULT_PORT 5454

void error(const char* msg, int code){
    //On va utiliser des exit() plutôt que des return (meilleure portabilité au sein du programme)
    perror(msg);
    exit(code);
}

void rand_pos(int* x, int* y){
    *x = 1 + rand()%N;
    *y = 1 + rand()%N;
    printf("Jeu initialisé ; trésor situé en %d %d\n", *x, *y);
}

/* =================================================================== */
/* FONCTION PRINCIPALE : SERVEUR ITERATIF                              */
/* =================================================================== */
int main(int argc, char **argv) {

    //A priori on n'a besoin que des coordonnées du trésor côté serveur
    int x_tresor = 4, y_tresor = 5;
    int randomize = 0; //indique si la position doit être randomisée à chaqeu partie

    int port = 0;
    if (argc > 1){
        port = atoi(argv[1]);
    }

    if (argc == 3 && strcmp(argv[1],"rand")==0) {
        srand(time(NULL));
        randomize = 1;
    }

    if (port == 0) port = DEFAULT_PORT;

    /* Creation socket TCP */
    int serv_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (serv_socket == -1) {
        error("Socket creation error", 1);
    }

    struct sockaddr_in serv_address;
    memset(&serv_address, 0, sizeof(serv_address));
    serv_address.sin_family = AF_INET;
    serv_address.sin_port = htons(port); /* host to net byte order (short) */
    serv_address.sin_addr.s_addr = htonl(INADDR_ANY); /* any interface */
    if (bind(serv_socket, (struct sockaddr*) &serv_address, sizeof(serv_address)) == -1) {
        close(serv_socket);
        error("Bind error", 2);
    }

    if (listen(serv_socket, MAX_QLEN) == -1) {
        close(serv_socket);
        error("Listen error", 3);
    }

    printf("Serveur lancé (port : %d)\n", port);

    struct sockaddr_in cli_address;
    socklen_t cli_adr_len = sizeof(cli_address);
    char buffer[MSG_LEN];
    int local_socket; //les bonnes pratiques voudraient qu'on déclare cette variable à l'intérieur de la boucle, mais il me semble qu'il y a un des profs de TP qui n'aime pas ça, alors dans le doute ...
    while(1){
        local_socket = accept(serv_socket, (struct sockaddr*)&cli_address, &cli_adr_len);
        if (local_socket < 0) {
            close(serv_socket);
            error("Accept error", 4);
        }

        printf("Client connecté (%s:%d)\n", inet_ntoa(cli_address.sin_addr), cli_address.sin_port);

        if (randomize){
            rand_pos(&x_tresor, &y_tresor);
        }

        /*
        NOTE : le client affichera "connexion réussie" et la grille de jeu même si le serveur (en mode itératif) est déjà occupé avec un autre client, et ne se bloquera qu'après
        avoir envoyé une première tentative (car le serveur ne répondra qu'après avoir fini avec le client actuel).
        Pour éviter ça (et ne lancer le jeu que quand le serveur est prêt à s'occuper de nous) on peut décider que le serveur doit avant toute chose envoyer un message
        "je suis prêt" au client, et, côté client, n'indiquer à l'user que tout est bon que lorsqu'on a reçu ce message du serveur.
        C'est ce que fait le send commenté ci-dessous, que j'ai préféré laisser en commentaire ne sachant pas dans quelle mesure on doit se limiter à l'énoncé
        */

        if (send(local_socket, buffer, MSG_LEN, 0) == -1){
            close(local_socket);
            error("Send error", 6);
        }

        int points;
        int xp, yp;
        do {
            /* Réception de la tentative (recv) */
            if (recv(local_socket, buffer, MSG_LEN, 0) == -1){
                close(serv_socket);
                error("Receive error", 5);
            }

            sscanf(buffer, "%d %d", &xp, &yp);
            points = recherche_tresor(N, x_tresor, y_tresor, xp, yp);
            printf("Tentative reçue (%d %d), le nombre de points est %d\n", xp, yp, points);

            /* Construction de la réponse (serialisation en chaines de caractères) */
            sprintf(buffer, "%d", points);

            /* Envoi de la réponse au client (send) */
            if (send(local_socket, buffer, MSG_LEN, 0) == -1){
                close(local_socket);
                error("Send error", 6);
            }

        } while (points);   //Si point est 0, alors le joueur avait trouvé le trésor donc partie terminée (le client va se déconnecter une fois qu'il aura reçu le message comme quoi il a eu 0 points sur ce coup)
        printf("Partie terminée\n");

        close(local_socket);
    }

    close (serv_socket);

    return 0;
} // end main
