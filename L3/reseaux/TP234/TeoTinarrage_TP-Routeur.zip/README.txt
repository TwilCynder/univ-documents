Bonjour,
je comptais terminer ce TP vendredi soir, mais n'ayant pas réussi à le lancer sur mon PC (j'utilise windows, je pensais qu'un VM fonctionnerait mais impossible d'utiliser xterm)
je n'ai pas pu le terminer, et ai du attendre aujourd'hui pour avoir accès à un ordinateur de la fac.
Je vous pris de m'excuser pour le retard.