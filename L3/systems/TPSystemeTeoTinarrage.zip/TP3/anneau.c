#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

typedef int[2] pipe;
int* pipes;

int main(int argc, char const *argv[])
{
  if (argc < 3){
    
  }
  return 0;
}
