#ifndef _AFFICH_H
#define _AFFICH_H

// Aficher son identite et attendre nbSec secondes
void afficher(int nbSec);

#endif
