from htrees import *
from htree_dot_noviz import display_htree 

from __future__ import print_function

a1 = Node(0.5, Leaf(0.2, 'a'), Leaf(0.3, 'b'))

def somme (ht):
    if isinstance(ht, Leaf):
        return(ht.val)
    else:
        return(ht.val + somme(ht.low) + somme(ht.high))

