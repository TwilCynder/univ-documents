/**
 * 
 */
package tp3;

import tp3.console.ConsoleJavaBoy;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Prince p1 = new Prince("Twil");
		Prince p2 = new Prince("Nillan");
	}

}
