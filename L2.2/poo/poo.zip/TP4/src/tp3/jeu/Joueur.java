package tp3.jeu;

public interface Joueur {
	public void gagner(int argent);
	public void perdre(int argent);
}
