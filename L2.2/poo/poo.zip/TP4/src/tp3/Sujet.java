package tp3;
/**
 * 
 * @author Sebastien Leriche, leriche@irit.fr
 * Fevrier 2006 - TP L3 Concepts de Programmation
 * 
 */
public interface Sujet {
	public String getNom();
	public int getArgent();
	public void run();
}
