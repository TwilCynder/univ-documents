Le protocole V4 (selective repeat) n'a pas été réalisé par manque de temps. 

Tous les autres protocoles ont été testés et sont supposés fonctionner, dans les conditions suivantes : 

V1 : erreur possible côté emetteur
V2 : erreur et perte sur l'emetteur, perte sur le recepteur
V3 : toutes les pertes/erreurs possibles
