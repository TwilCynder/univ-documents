clear
gcc -Wall -Wextra $1 -o $2
