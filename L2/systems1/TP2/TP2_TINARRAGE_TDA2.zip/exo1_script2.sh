#!/bin/sh

rm -r "$1"
